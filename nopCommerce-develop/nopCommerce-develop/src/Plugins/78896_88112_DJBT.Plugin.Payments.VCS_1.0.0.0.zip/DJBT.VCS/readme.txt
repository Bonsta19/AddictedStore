1. 'DJBT.VCS' contains binaries. Just drop it into \Plugins directory on your server.
Payment integration for www.vcs.co.za
Use GitHub for source, bugs & feature requests:
https://github.com/zs2hx/nop.Plugin.Payments.VCS